#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 21 00:07:40 2023

@author: austinhenley_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32354
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Create function - "C" of CRUD
    def create(self, data):
        if data is not None:
            if not isinstance(data, dict):
                raise TypeError("Data must be a dictionary.")
            
            insertResult = self.collection.insert_one(data)  # data should be dictionary      
            if insertResult.inserted_id:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Read function - "R" of CRUD
    def read(self, searchQuery):
        if searchQuery is not None:
            # Ensuring query is a dictionary
            if not isinstance(searchQuery, dict):
                raise TypeError("Query must be a dictionary.")
                
            # Finding records that match query
            readResult = self.collection.find(searchQuery)
            resultList = list(readResult)
            
            # If list is not empty, return items
            if len(resultList) > 0:
                return resultList
            else:
                return []
        else:
            readResult = self.collection.find({})
            
# Update function - "Update" of CRUD
    def update(self, searchQuery, updateQuery):
        if searchQuery is not None and updateQuery is not None:
            # Ensuring either query is a dictionary (Seperated for error reporting)
            if not isinstance(searchQuery, dict):
                raise TypeError("Search Query must be a dictionary.")
            if not isinstance(updateQuery, dict):
                raise TypeError("Update Query must be a dictionary.")
                
            # Finding and updating records that match search query
            updateResult = self.collection.update_many(searchQuery, {'$set': updateQuery})
            
            # Returning the number of documents updated
            return f"{updateResult.modified_count} record(s) updated"
        else:
            raise Exception("Cannot perform update, because search query parameter or update query parameter is empty")
            
# Delete function - "Update" of CRUD
    def delete(self, deleteQuery):
        if deleteQuery is not None:
            # Ensuring the query is a dictionary
            if not isinstance(deleteQuery, dict):
                raise TypeError("Delete Query must be a dictionary.")
                
            # Finding and updating records that match search query
            deleteResult = self.collection.delete_many(deleteQuery)
                                                       
            # Returning the number of documents updated
            return f"{deleteResult.deleted_count} record(s) deleted"
        else:
            raise Exception("Cannot perform delete, because delete query parameter is empty")
            

